# 已确认签约自动海康远程资格：源码交付

日期：2026-11-26（Asia/Shanghai）。版本：`0.1.0-beta.22-signed-lease-remote-source.1`。

已实现代码及离线验证；未部署、未上传微信体验版、未启动真实worker或向设备发令。登记已确认签约事实不是在线法律签署，不表示CORE-01真实全链路已经验收。

## 固定版本

- 源码分支：`feat/signed-lease-hikvision-remote-unlock-2026-11-26`。
- 完整源码提交：`66e0395c105cda21244d375ef6d01682bc6cfe1e`。父`2a45898aca74592a59a9d70e2f5b76e5c44cd51a`；该实现提交父为`d798be60b2968a46cac22b6a5cdb25acc5e7b467`。
- 首实现提交测试文件末尾有多余空行，已追加独立格式更正，不改写历史；最终累计diff及HEAD show检查均通过。
- 源码ZIP：`SMART-PM-v0.1.0-beta.22-signed-lease-remote-source.1-66e0395c-checkin-face-test.zip`，10278606字节；SHA-256 `7342b3e81216f7aca4bab4718009efd1dd977fb8c04b40773a244eb887780aba`。
- 普通显式refspec推送；远端完整SHA已核对一致。未改main、未合并或改写历史。

## 已实现的流程

1. 可信手机号注册/复用本人住户，保持注册不授予房屋或门禁权限。
2. 管理员依据实际已确认合同录入本人、房产、明确租期及签约证据引用；合同、远程资格、本人索引和审计同事务落盘，不增加门禁申请或二次审批。
3. 本人在起租日前不能开门；租期内每天24小时可明确点击远程开门。最后租赁日计入，内部截止为下一日上海00:00，不默认租期或设备。
4. 云端持久幂等、在途单飞；worker准备安全连接并实读型号后，再取得服务端最新begin许可。普通open受不可延长的绝对任务/租期截止约束，TLS放行和Digest重发均复核。
5. 设备协议接受、失败、未知分别保存；HTTP200不当成成功，设备接受也不当成物理锁释放。未知/崩溃不自动重排或重发，清理失败保留已知设备事实并停止worker、非零退出。
6. 人脸后补，既有隔离入住/人脸worker业务未修改。押金及第三方支付不参与本流程。

后台新增签约确认、撤销、门绑定/worker/程序配置、未知结果处置及当前记录的脱敏只读查询；沿用管理员认证、Origin和CSRF。旧开门路径拒绝海康/未知平台，不允许借旧public/houses/admin权限回落通通锁。

## 实测验证

Linux / Node v24.22.1 / Python3.12.14。在干净Git归档解压源码中执行`python scripts/package-release.py --live --checkin-face`；实际命令、时间、退出码和逐项输出在package.execution.json、package.stdout.raw.txt、test-report.txt。

| 验证 | 结果 |
|---|---|
| 显式离线组合profile（含新cloud/UI/admin/worker/deadline/集成） | 610/610；0失败、0取消、0跳过、0todo |
| 归档安全及强制门禁 | 6/6 |
| 新来源清单 | 207项匹配；独立部署身份和手机号proof helper原字节一致 |
| 旧来源登记原字节 | 61项与原登记/已记录补丁吻合；未执行需要安装依赖的完整verify-import |
| 既有小程序/测试入住静态门禁 | 184源文件、0违规；该数字不是全仓扫描数 |
| 小程序静态结构 | 12页，974 KiB；未做微信编译/视觉或真机验收 |
| 新模块及所改入口语法检查 | 11文件通过 |
| 最终ZIP独立逐文件比对 | 844文件均匹配固定Git blob；207项来源hash也匹配归档 |
| Git空白检查 | 最终累计diff --check及HEAD show --check退出0 |

组件定向数已经包含在610内，不另外累加：core50；前端新16项及兼容37共53；后台16；worker22；实际client逻辑安全VM deadline4；跨组件3；旧通道隔离2。其余是保留的既有回归。

跨组件3项使用实际手机号注册、管理facade、云服务、mini API、worker和provider模块，微信SDK/数据库/设备均为安全合成依赖：正常签约后无人脸亦可发令；型号GET期间撤销零PUT；租期边界到达零begin/PUT。绝不代表真实微信/云/设备测试。

独立内容复核交叉进行，实施者不把自己模块算独立通过：另一位agent读core/UI/admin；core实施agent读他人worker/provider/UI。发现并关闭绝对deadline、迟到回包/旧查询覆盖、modal锁窗口和cleanup错误路径；原负控失败及修正后日志均保留。deadline验证通过安全VM执行实际client/agent/Digest代码，仅替换精确import/export锚和外部传输，不做真实TLS。

## 使用与剩余前置

解压源码ZIP后，用微信开发者工具导入其中SMART-PM/项目根目录。源码带正常项目配置，但本轮没有微信编译或平台上传，不是已可扫码访问的体验版。

运行入口：后台`/signed-lease-access.html`；本地worker说明见`tools/signed-remote-worker/README.md`。默认CLI不执行；显式--execute-loop才会持续出站处理新任务。本轮没有启动该模式。

小程序allowDeviceOperations和signedLeaseRemoteEnabled均false；云端配置缺失默认关闭。实际住户、rooms.houseId、已确认签约证据和手填租期、设备映射、允许门号、worker凭据、可信CA/主机名/公开证书pin、现场工作机时钟、私有集合规则及IAM/索引均需在另行授权的环境核实配置；不得用示例值或目标值冒充实读。

若提交回执丢失而未取得taskId，页面保持未知并禁止自动重发；该异常需从已认证后台/云记录核对原任务，不得把重新登录当成事实已确认。此安全处理不改变正常签约后无需额外申请的规则。

尚未验证：真实微信手机号授权、管理SDK/云事务/规则与索引、真实TLS/设备固件、平台编译上传、现场门锁释放。也未实现本模块外的正式合同生成/电子签字供应商或法务生效政策。既有102现场开门UNKNOWN_NO_RETRY结果不被本次合成测试覆盖。

NO-GO及真实上传、部署、设备、业务云与支付执行冻结保持；本交付不放行CR-3/E1/E2或其它冻结线。
