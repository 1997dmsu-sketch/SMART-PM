# A 路独立只读复审

结论：**PASS（本次固定源码的 A 路静态复审范围）**。无实质发现。没有可列为 P0/P1/P2/P3 的已证缺陷；这不是实际云、真机、设备或现场验收通过，也不批准部署或真实发令。

报告日期按客户端：**2026-11-27，Asia/Shanghai**。本轮实际首个核对时间原样为 `2026-11-26T20:21:51Z`；源码主体复核阶段的差异核对时间原样为 `2026-11-26T20:24:02Z`。报告落盘 UTC 时间见文末。

## 独立性与执行边界

本审查 Codex 未参与该候选实现；本轮以源码控制流和相关测试定义自行判断。另派未参与实现的只读协助者核查身份/手机号 proof/旧入口边界，协助者没有写文件或运行测试，其结论已逐项核对，不用原实现者自测替代独立内容结论。

唯一写入为本专属目录下的本报告。没有修改仓库、提交、推送、安装依赖、重跑 610、执行候选模块/worker CLI、部署或上传；没有访问真实云、账号、设备、支付或读取真实凭据。未重开或运行旧 CR-2、EOF、WP06、D/E、全量 npm test 或负控。

## 固定对象与适用说明

| 核对项 | 实际结果 |
| --- | --- |
| 工作区 | `/workspace/SMART-PM-signed-remote-unlock-20261126` |
| 分支 | `feat/signed-lease-hikvision-remote-unlock-2026-11-26` |
| 固定完整 HEAD | `66e0395c105cda21244d375ef6d01682bc6cfe1e` |
| HEAD 父提交 | `2a45898aca74592a59a9d70e2f5b76e5c44cd51a` |
| 父提交的父提交/累计基线 | `d798be60b2968a46cac22b6a5cdb25acc5e7b467` |
| 累计基线祖先核对 | `git merge-base --is-ancestor` 返回 0 |
| 初末工作区 | `git status --short` / `git status --porcelain=v1` 均无输出；末次 unstaged/cached diff 均返回 0 |
| AGENTS.md | `/AGENTS.md`、`/workspace/AGENTS.md`、仓库根均不存在；`rg --files -g AGENTS.md` 未发现仓库适用说明，协助者也未发现 |
| 远端 | A 路未自行联网。继承本轮主 Codex 的实际 `git ls-remote --heads origin`（exit 0）回报：源码 ref 为固定 HEAD；交付 ref 为 `973879dce59b83983cae372ba8e9c0e1aca6b5bf`。未以远端对象替换固定审查对象 |

已读 `docs/tasks/SIGNED-LEASE-HIKVISION-REMOTE-OPEN-IMPLEMENTATION-2026-11-26.md` 全文、`docs/deployment/signed-lease-access/client-rules.json`、`indexes.json` 及云函数 README。按产品冻结审查：管理员可信记录的是已确认签约事实；签约事实与资格同事务；注册不授权；照片、人脸、押金、支付均非前置；上海起止日期首尾计入、内部上界不计入；UNKNOWN 不重排/重发。未把该入口理解成实际电子签字或法律效力裁定。

## 发现表

| ID | 级别 | 文件行 | 可触发条件 | 影响 | 最小修法 | 建议验证 |
| --- | --- | --- | --- | --- | --- | --- |
| — | — | — | 无实质发现 | — | — | 真实环境项维持另行授权后验证；本轮不运行 |

## 独立静态核查结果

以下行号均针对上述固定 HEAD。它们是本轮阅读控制流所得，不是把继承测试数当作独立通过。

| 核查点 | 可核对的实现与判断 |
| --- | --- |
| 身份及跨 APPID/住户隔离 | `cloudfunctions/signedLeaseAccess/lib/service.js:128-145` 由 user 点读反查可信 APPID/OPENID、canonical identity 和私有 phone proof；resident 再核上下文 APPID/OPENID。`lib/identity-core.js:49-56` 将 identity、user、APPID/OPENID 及规范 identity ID 精确绑定。租客提交的 userId、房产、门号或租期不能进入开门输入。没有用查询首行选择本人身份。 |
| phoneLogin 接线 | `lib/phone-proof.js:9-20` 核 proof 的 schema、APPID、phoneHash、identityId、userId 和正整数 verifiedAt，并要求 `verifiedAt === user.phoneBoundAt`。两个 helper 本地副本与 `cloudfunctions/phoneLogin/lib/` 的对应文件经只读 cmp 完全相同；phoneLogin 相较累计基线没有改动。缺 proof 不取得签约资格，也不通过请求/执行前复核。 |
| 云入口及管理员边界 | `index.js:23-35` 只接受显式 action 和封闭字段；worker 走独立 token 路径；admin action 先 `verifiedAdmin`；`service.js:492-493` 在可信住户记录上检查 admin role。服务库内部 `admin(actor)` 视 actor 为服务端信任边界，不能单凭该检查宣称外部调用者可自报 admin。后台 facade/adapter 只补读了解接线，不替代 B 路完整后台审查。 |
| 注册与签约原子性 | `service.js:284-327` 在 `txRun` 的同一 callback 内读取 canonical、固定 room 文档、绑定及旧合同，随后写 contract、grant、本人 index 和 audit；签约路径不写 users.houses、不创建 TASKS、不调用设备。不存在租客额外申请或二次门禁审批条件。 |
| 签约幂等及损坏配对数据 | `service.js:294-318` 阻止更换合同住户/房产/identity/绑定、验证旧合同和 APPID；仅相同 signed 内容及允许的 expectedRevision 才回放，且回放必须验证 grant、index 和合同成员关系。缺失/错配 grant 或 index 不静默修复、不返回确认成功。新合同若残留同名 grant 也拒绝。 |
| 修改/撤销与并发 | 修改使用 `expected(old, expectedRevision)` 并递增合同及 grant revision；撤销 `service.js:329-339` 在同事务改 contract/grant 并审计。request/claim/begin 点读相同权威合同、grant、binding/program；旧快照在 `service.js:187-193` 被拒。正在执行的不承诺撤回物理动作，符合冻结边界。真实 SDK 的冲突检测及重试语义未实测。 |
| 精确租期与门绑定 | `service.js:52-72` 将严格日期转上海午夜，endDate 次日午夜为 validUntil；`167-193` 重算并比较持久日期边界，拒未开始和 `timestamp >= validUntil`。`setDoorBinding:259-265` 查询最多两行要求恰一，再事务点读固定 roomDocumentId；后续 `room:147-151` 复核同文档/houseId。未把配置时查询夸成全库唯一索引；任务文档已明确其他 rooms 写者不受本模块全局唯一锁控制。 |
| SDK 显式错误与事务回调 | `lib/identity-core.js:64-90` 验响应 data、显式 code/errCode 和点读 ID/数组唯一性；`service.js:44-50` 验写入显式错误；`119-127` 只有事务工作和 DB audit。任务/签约事务 callback 内无设备或支付调用。`admin-web/lib/tenant-auth-cloud-database.mjs:6-16,19-27,70-72` 补读表明管理 SDK adapter 将其 set 格式转换并交由 SDK 管重试/提交。未发现 SDK 显式失败被当成功的源码路径。 |
| 全局开关及 worker 身份 | `program:153-156` 缺配置默认关闭；`gate:183-186` 校验 enabled、派发时额外 dispatchEnabled。`worker:158-165` 校验 enabled、token 长度/字符、合法 hash/deviceKey/revision，并用 timingSafeEqual 比较 token hash。claim 在 query 前及事务内重验 worker；begin 检查 workerRevision，不能靠 WX 声明代替 worker 身份。请求排队与派发开关是两层：dispatchEnabled=false 可保留短时 queued，但 claim/begin 不发执行许可。 |
| claim/begin 队列状态 | `claimOpen:416-435` 只查询同 deviceKey 的 queued，逐候选事务重读；过期 queued/claimed 终结且释放；权限失效 deny；成功 claim 写 claimId、workerId、workerRevision。`beginOpen:437-455` 要求 claim/worker/device/revision 精确匹配及 claimed，复核有效期和全部授权后 CAS 到 executing。再次 begin 因 revision/status 不能重复执行。 |
| UNKNOWN 与单资格在途锁 | `expire:200-208` 将过期 executing 变 unknown 并保留 grant activeTaskId；`requestOpen:384-390` 对 queued/claimed/executing/unknown 未处置任务返回在途错误。`resolveUnknown:481-489` 仅对 unknown 或到期 executing、当前 expectedRevision 做显式审计处置并释放；不会生成新任务、重新入队或重发旧任务。release 在 `196-198` 只有 grant 当前仍指该 task 才清空，迟报旧任务不会清掉后来新任务的锁。 |
| 回报、迟到事实及持久回放 | `reportOpen:457-478` 验 worker/claim/device；协议成功只能 status=device_confirmed 且 code='1'；只有 executing/unknown 且 executionRevision 匹配能首次报告，保留报告 receipt 幂等。报告不重做租期 gate，所以合法已执行任务可在到期后保留已知设备事实。定时 expire 生成的 unknown 没有 reportReceipt，允许迟到首次已知回报；管理员已处置也不阻止该事实写入，并保持 resolved 标记。已有 reportReceipt 后不同状态报告为 REPORT_CONFLICT，属于首次报告封存语义，本轮没有把它猜测为“丢失确定事实”缺陷。 |
| requestId 与错误优先级 | `requestOpen:372-405` 先验证当前 resident，再点读本人 requestId 派生的持久 task；同 requestId 换 contract 报冲突；同一历史任务只 expire/回放，不重排。新的 requestId 才做 gate，再处理在途单资格锁。因而旧请求回放可在合同后来撤销/到期后返回历史状态，仍不能获得新的执行许可；新请求应先报当前授权失败。输入错误先于授权、resident 先于历史 task，避免凭 task ID 读取他人状态。没有把“历史状态回放”误判为“撤销后重新授权”。 |
| 旧通道拒海康回落 | `cloudfunctions/unlock/index.js:238-242` 与 `cloudfunctions/getDevices/index.js:51-52` 仅支持既有 undefined/ttlock/tuya；显式 hikvision 或未知平台不会回落到旧开门/设备返回路径。本轮另读 `tests/signed-remote-legacy-boundary.test.cjs` 的全部隔离定义，未执行。 |

## 证据范围与继承证据

本轮独立阅读的主要源码为 `cloudfunctions/signedLeaseAccess/**` 全部；相关既有 phoneLogin identity/proof 与入口；旧 unlock/getDevices 边界。测试定义阅读包括 `tests/signed-lease-access-core.test.cjs` 全部、`tests/signed-lease-integration.test.cjs` 全部及 legacy boundary；补读 `tests/support/tenant-auth-memory-db.cjs` 的事务模型，并沿 worker report 调用点理解云协议。worker/provider/TLS、UI 和后台全量审查属于其他路，本报告不替他们背书。

已读的 core 测试定义覆盖签约同事务、身份/proof、日期、幂等、SDK 显式错/提交失败、住户隔离、singleflight、begin 复核、UNKNOWN、到期迟报及损坏 contract/grant/index。`tests/support/tenant-auth-memory-db.cjs:3-5` 自述是合成数据库 oracle，不能证明真实 CloudBase 行为；本轮未运行这些定义。

下列为**继承证据**，仅核对既有原件及对象指向：

- `/workspace/artifacts/signed-remote-unlock-2026-11-26/package-attempt-01/package.execution.json` 记录固定 HEAD，原命令 `scripts/package-release.py --live --checkin-face`，原始时间 `2026-11-26T17:33:36.492185+08:00` 至 `2026-11-26T17:34:03.182507+08:00`，exit 0；其 scope 明确为 guarded offline profile。SHA256：`1ff0d036f7eeeceb3e197577907fff6ff36a397204a56148dd7a710a504189f3`。
- 同目录 `package.stdout.raw.txt:1015-1021` 为 tests 610、pass 610、fail/cancelled/skipped/todo 均 0。该原始输出 SHA256：`93c6ecc163c800cc4a8e85835fc26aaf89bc8bc7dd09da283b91bc19b9928570`；`delivery/package.stdout.raw.txt` 的 SHA256 完全相同。
- `delivery/test-report.txt` 尾部亦记 610/610 和后续静态/打包检查；SHA256：`12ffdb9d60ee761a421a1ce295cfc8020a2bf3432f20158f74bff0b4188cee2a`。
- `delivery/INDEPENDENT-CONTENT-REVIEW.md` 明说它是主 agent 根据旧协作消息整理的摘要，而非历史 REVIEW.md 原件；只作为历史背景，不作为本轮 A 路独立结论来源。

没有为本报告重跑上述命令，也没有把“610/610”改称本轮独立复测。

## 未验证项与结论边界

1. 未接触真实 CloudBase：实际事务 SDK/运行时、回调重试及冲突语义、集合/IAM/client-deny 规则、索引/限额与部署状态均未实测。`client-rules.json` / `indexes.json` 明确只是部署建议，不能据此宣称已应用。
2. 未读取或验证真实住户、签约证据、房产、门绑定、worker 凭据、网络、TLS、真实型号/协议响应、微信真机或锁释放。实际真实已确认签约事实仍需负责人按真实材料核对。
3. 只做了静态并发推演，没有独立执行签约修改/撤销与 claim/begin/report 的竞争，也没有运行错误优先级/损坏记录/late-known 的新合成验证。可按后续授权补充有针对性的离线验证；本次无须为无已证缺陷重跑旧冻结套件。
4. 首次 unknown 报告封存后不接受另一已知报告，是当前明文 receipt 幂等实现；定时 unknown 的迟到首次已知报告另有路径。若产品另要求“已报告 unknown 后仍可追加可认证新事实”，需要先明确事实来源、不可重发和幂等规则，再定向验证，不能仅凭静态状态不同先定实质缺陷。
5. PASS 只表示本固定对象的 A 路静态范围内无实质发现；实际验收、部署、平台上传或真实开门均未获本报告自动授权。完成后交主 Codex 汇总，A 路停手。

收尾源码工作区核对实际 UTC 为 `2026-11-26T20:25:53Z`，HEAD 仍为固定对象，status 无输出，unstaged/cached diff 均返回 0。

报告落盘实际 UTC：`2026-11-26T20:25:46Z`。
