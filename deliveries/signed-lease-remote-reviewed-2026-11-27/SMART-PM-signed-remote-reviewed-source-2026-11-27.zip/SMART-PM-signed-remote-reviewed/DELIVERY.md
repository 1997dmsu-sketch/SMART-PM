# 签约租期海康远程开门：独立复审退修交付

日期：2026-11-27，Asia/Shanghai。版本：`0.1.0-beta.22-signed-lease-remote-source.2`。

**B-01至B-04及C-01五项代码缺陷已完成修复并通过原独立复审方的限定复验。真实部署、微信体验版上传、真实TLS/云/设备/支付或现场门锁验收没有执行或获批。**

## 固定对象

- 源码提交：`6fa36b5b60760d3d26fad2c95157954364e33e76`。
- 直接父：`66e0395c105cda21244d375ef6d01682bc6cfe1e`。
- 源码分支：`fix/signed-remote-independent-review-2026-11-27`；普通显式refspec push及ls-remote已经核对完整SHA一致。
- 本版13个文件差异：B六个、C两个、版本三个、来源清单一个、退修卡一个；未修改A云/身份/签约后台内容、既有人脸worker业务或任何真实配置。
- 内层源码ZIP：`SMART-PM-v0.1.0-beta.22-signed-lease-remote-source.2-6fa36b5b-checkin-face-test.zip`；10288342字节；SHA-256 `170e62d7bc5d44dcef2860afbfc03416c91813f1d89bbcd352c1a997770f4e2d`。
- 外层ZIP是源码和证据的交付容器，其交付提交不是内层源码SHA。SHA、文件大小及逐文件清单随包提供。

## 修复与复验

| 项 | 修复 | 原独立复验 |
|---|---|---|
| B-01 / P1 | 在异步socket交接和最终应用层write前再次核验同一截止 | CLOSED |
| B-02 / P1 | claim首次锚定epoch+monotonic预算，贯穿准备、GET、begin、初发/401/TLS/write，不重新延长 | CLOSED |
| B-03 / P2 | 只接受RFC JSON四类ASCII语法空白，不擦除非法首尾；XML同样失败关闭 | CLOSED |
| B-04 / P2 | 标量状态码闭式归一；worker独立类型校验，不把数组送入唯一report | CLOSED |
| C-01 / P3 | 保护新登录owner的视图与操作，旧回调丢弃；logout/失效旧视图继续清隐私 | CLOSED |

原A静态PASS按未变源码继承，不用本轮结果倒写旧B/C报告。原66e0395的NEEDS_REVISION与旧交付原件保留，不将修订版结果冒称原版通过。

原B复验报告：10376字节，SHA-256 `07ee7ae3e58ca0c0e2efecdb172953bec0fcd36543605d76d0708fce0c8c8e32`。原C复验报告：7558字节，SHA-256 `deba9b46c3b32675f8cb3b4e61d8238a72f1f8cbfd6a69dcff6fc00d473d466e`。主Codex已读取报告并复算一致；B侧19项SHA256SUMS亦独立核对。原报告、修复方红控、独立报告及命令/原样输出都分目录保留，不改写历史或把作者结果写成独立运行。

## 实际检查

Linux、Node v24.22.1、Python3.12.14。原独立B执行预载no-forward guard的两文件合成命令，37/37 exit0；另在自有副本用旧三源文件搭新断言，11/11按预期失败，exit1，失败来自缺陷断言而非装配。原独立C执行专属suite32/32 exit0，并运行五个安全VM对照exit0。上述用例与组合profile重叠，不累加为完成率。

主Codex在干净Git归档解压树执行：

```text
python scripts/package-release.py --live --checkin-face
```

结果：**637/637**，fail/cancelled/skipped/todo全0；归档安全**6/6**；总退出0，包装器stderr为空。12页面静态结构975KiB，207来源hash通过，845归档文件逐一匹配固定Git blob，旧来源61项字节核对通过。不是微信编译、Windows兼容、真实管理SDK/云事务或真机测试。命令、时间、Node版本和原始输出见package.execution.json、package.stdout.raw.txt及test-report.txt。

默认runtime与66e0395原字节一致：allowDeviceOperations和signedLeaseRemoteEnabled均false。源码ZIP不含历史deliveries或本地worker配置；原云业务和人脸worker业务字节未变。Git累计diff --check及HEAD show --check均通过，源码工作树干净。

## 产品及实际环境边界

后台录入已确认签约事实，同事务自动给本人、房产、门和明确租期生成资格，无额外租客申请或门禁二次审批。人脸后补；手机号注册不授权，押金和第三方支付不是前置。本模块不替代合同实际签署、正式合同生成或法律效力裁定。

发送截止保护的是最后可控的应用层TLS写入点，不能撤回已被TLS/内核接受的字节；不保证设备接收或物理动作恰在截止毫秒前。初始工作机与云时钟可信度、证书链/主机名/pin、实际型号门号、云规则/IAM/索引、实际合同/102绑定/手填租期/worker及现场释放均仍需获授权后的实测。HTTP200或device_confirmed不等于门锁释放。保留此前现场UNKNOWN_NO_RETRY记录。

## 本地Harness准备交付尚未内容通过

负责人回报派单`hrun-mwy0lzpx-b32c39`、session`session-72edc5c2-d44d-4e21-aa04-1c6fb8f40ee3`已completed，三份准备报告在Windows工作区。当前云端只收到路径及完成回报，未收到三份原文/实际字节和哈希，主Codex内容复核为**待取件**；包内DEPLOYMENT-PREP-REPORTED-NOT-REVIEWED.json只是该回报的来源登记，不是假原件。

准备材料针对旧66e0395、旧610/610；复核后仍需对本次固定修订补差异，不能把旧材料或completed状态当新候选可部署证据。真实云配置、合同、102、租期、体验成员、现场证据与回滚锚点继续UNVERIFIED。

外层和内层源码ZIP可下载、保存原件，导入微信开发者工具查看源码；没有上传可扫码体验版。NO-GO及所有未授权的上传、部署、真实云/设备/支付操作继续冻结，CR-2/D/E/EOF/WP06等既有线不重开。
