'use strict';
// Independent reviewer controls. Reads fixed source; all WX responses are in memory.
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const assert = require('node:assert/strict');
const { createRequire } = require('node:module');
const root = process.cwd();
const guard = globalThis.__DSH_D_NETWORK_GUARD__;
assert.ok(guard, 'preload the network guard');
const baseline = guard.snapshot();
const clone = value => JSON.parse(JSON.stringify(value));
const defer = () => {
  let resolve, reject;
  const promise = new Promise((yes, no) => { resolve = yes; reject = no; });
  return { promise, resolve, reject, started: false };
};
const tick = () => new Promise(resolve => setImmediate(resolve));
function fixture() {
  let current = 'A';
  const config = { mode: 'live', cloudEnv: 'synthetic-env', signedLeaseRemoteEnabled: true, allowDeviceOperations: true };
  const calls = { opens: [], lists: [], modals: [] };
  const blockedLists = new Map();
  let oldOpen;
  const door = owner => ({ contractId: 'contract-' + owner, doorBindingId: 'binding-' + owner, houseId: 'house-' + owner,
    displayName: 'Synthetic ' + owner, startDate: '2026-11-27', endDate: '2026-11-27',
    validFrom: 1795708800000, validUntil: 1795795200000, canOpen: true, reason: 'READY' });
  const receipt = owner => ({ taskId: 'open_' + (owner === 'A' ? 'a' : 'b').repeat(64), status: 'queued', expiresAt: 1795708805000 });
  const result = data => ({ result: { code: 0, data } });
  const wx = { stopPullDownRefresh() {}, showToast() {}, switchTab() {}, showActionSheet() {},
    showModal(options) { calls.modals.push(options); }, cloud: { async callFunction(request) {
      const owner = current;
      if (request.name === 'phoneLogin') {
        current = request.data.code;
        return { result: { code: 0, userInfo: { _id: 'user-' + current, role: 'user', houses: [], points: 0 } } };
      }
      if (request.name === 'getDevices') return result({ devices: [] });
      if (request.name === 'unlockRecords') return result({ records: [{ id: 'record-' + owner, doorName: 'Synthetic ' + owner, success: false, time: 'synthetic' }] });
      if (request.data.action === 'listDoors') {
        calls.lists.push(owner);
        if (blockedLists.has(owner)) { const block = blockedLists.get(owner); block.started = true; return block.promise; }
        return result({ enabled: true, doors: [door(owner)] });
      }
      if (request.data.action === 'requestOpen') {
        calls.opens.push({ owner, data: clone(request.data) });
        if (owner === 'A' && oldOpen) { oldOpen.started = true; return oldOpen.promise; }
        return result(receipt(owner));
      }
      throw new Error('Unexpected synthetic call');
    } } };
  const apiFile = path.join(root, 'miniprogram/services/api.js');
  const localRequire = createRequire(apiFile);
  const apiModule = { exports: {} };
  vm.runInNewContext(fs.readFileSync(apiFile, 'utf8'), { module: apiModule, exports: apiModule.exports, wx,
    require(name) { return name === '../config/runtime' ? config : localRequire(name); } });
  const api = apiModule.exports;
  const gateModule = { exports: {} };
  vm.runInNewContext(fs.readFileSync(path.join(root, 'miniprogram/utils/require-login.js'), 'utf8'), { module: gateModule, wx });
  let definition;
  vm.runInNewContext(fs.readFileSync(path.join(root, 'miniprogram/pages/unlock/index.js'), 'utf8'), { wx,
    getApp: () => ({ globalData: {} }), Page(value) { definition = value; },
    require(name) { if (name === '../../services/api') return api; if (name === '../../utils/require-login') return gateModule.exports; throw new Error(name); } });
  const page = { ...definition, data: clone(definition.data), setData(value) { Object.assign(this.data, value); } };
  return { api, page, calls, door, receipt, result,
    blockOpenA() { oldOpen = defer(); return oldOpen; },
    blockList(owner) { const block = defer(); blockedLists.set(owner, block); return block; },
    async login(owner) { await api.loginWithPhone(owner); },
    async modal() { await page.requestUnlock(page.data.locks[0]); return calls.modals.at(-1); },
  };
}
async function originalScenario() {
  const f = fixture();
  await f.login('A'); await f.page.onLoad({});
  const old = f.blockOpenA();
  const first = await f.modal();
  const oldWork = first.success({ confirm: true }); await tick(); assert.equal(old.started, true);
  f.api.logout(); await f.login('B'); await f.page.onShow();
  const second = await f.modal();
  const owner = f.page._unlockOperation, version = f.page._viewVersion;
  const before = clone({ locks: f.page.data.locks, confirming: f.page.data.confirming });
  old.resolve(f.result(f.receipt('A'))); await oldWork;
  assert.equal(f.page._unlockOperation, owner); assert.equal(f.page._viewVersion, version);
  assert.deepEqual(clone({ locks: f.page.data.locks, confirming: f.page.data.confirming }), before);
  await second.success({ confirm: true });
  assert.equal(f.calls.opens.length, 2); assert.equal(f.calls.opens[1].owner, 'B');
  assert.equal(f.page.data.signedOpen.contractId, 'contract-B');
  return { control: 'original C-01 sequence', preservedBModal: true, signedCalls: 2, explicitBCalls: 1 };
}
async function hangingOldRefresh() {
  const f = fixture(); await f.login('A'); await f.page.onLoad({});
  const blockA = f.blockList('A'); const oldLoad = f.page.load(); await tick();
  assert.equal(blockA.started, true); assert.equal(f.page.data.loading, true);
  f.api.logout(); await f.login('B');
  const blockB = f.blockList('B'); const newLoad = f.page.load(); await tick();
  assert.equal(blockB.started, true, 'B direct load must bypass stale A loading guard');
  assert.deepEqual(clone(f.page.data.locks), []);
  assert.equal(JSON.stringify(f.page.data.records).includes('record-A'), false);
  assert.equal(f.page._privateViewEpoch, f.api.getLoginEpoch());
  const version = f.page._viewVersion;
  blockA.resolve(f.result({ enabled: true, doors: [f.door('A')] })); await oldLoad;
  assert.equal(f.page._viewVersion, version); assert.equal(f.page.data.loading, true);
  assert.deepEqual(clone(f.page.data.locks), []);
  blockB.resolve(f.result({ enabled: true, doors: [f.door('B')] })); await newLoad;
  assert.equal(f.page.data.locks[0].contractId, 'contract-B'); assert.equal(f.page.data.loading, false);
  return { control: 'A refresh hanging then B direct load without onShow', clearedAImmediately: true, preservedBLoading: true, finalOwner: 'B' };
}
async function epochAcrossLoginCheck() {
  const f = fixture(); await f.login('A'); await f.page.onLoad({});
  const pause = defer(), original = f.page.requirePrivate.bind(f.page);
  let first = true;
  f.page.requirePrivate = async (...args) => {
    const allowed = await original(...args);
    if (first) { first = false; pause.started = true; await pause.promise; }
    return allowed;
  };
  const oldLoad = f.page.load(); await tick(); assert.equal(pause.started, true);
  const listCount = f.calls.lists.length;
  f.api.logout(); await f.login('B'); pause.resolve(); await oldLoad;
  assert.equal(f.calls.lists.length, listCount, 'old load may not issue lists under replacement login');
  assert.deepEqual(clone(f.page.data.locks), []); assert.deepEqual(clone(f.page.data.records), []);
  assert.equal(f.page._privateViewEpoch, f.api.getLoginEpoch()); assert.equal(f.page.data.loading, false);
  await f.page.load(); assert.equal(f.page.data.locks[0].contractId, 'contract-B');
  return { control: 'epoch changes while load awaits login check', staleLoadIssuedLists: false, oldPrivateDataCleared: true, nextBLoadWorks: true };
}
async function fulfilledPageBoundary(source) {
  const f = fixture(); await f.login('A'); await f.page.onLoad({});
  const old = defer();
  // Deliberately fulfill across the API boundary to exercise the page's own guard.
  // Real api.js would reject this stale epoch before the page receives the value.
  if (source === 'request') {
    const original = f.api.requestOpen;
    f.api.requestOpen = input => input.contractId === 'contract-A' ? (old.started = true, old.promise) : original(input);
  } else {
    f.api.getOpenResult = () => { old.started = true; return old.promise; };
  }
  const first = await f.modal(); let oldWork = first.success({ confirm: true });
  if (source === 'query') { await oldWork; oldWork = f.page.querySignedOpen(); }
  await tick(); assert.equal(old.started, true);
  f.api.logout(); await f.login('B'); await f.page.onShow(); const second = await f.modal();
  const owner = f.page._unlockOperation, version = f.page._viewVersion;
  old.resolve({ ...f.receipt('A'), message: 'synthetic', resolved: false }); await oldWork;
  assert.equal(f.page._unlockOperation, owner); assert.equal(f.page._viewVersion, version);
  assert.equal(f.page.data.confirming, true); assert.equal(f.page.data.locks[0].contractId, 'contract-B');
  await second.success({ confirm: true });
  assert.equal(f.calls.opens.filter(call => call.owner === 'B').length, 1);
  assert.equal(f.page.data.signedOpen.contractId, 'contract-B');
  return { control: 'page fulfilled ' + source + ' after epoch switch (stubbed API boundary)', preservedBModal: true, explicitBCalls: 1 };
}
(async () => {
  const controls = [];
  controls.push(await originalScenario());
  controls.push(await hangingOldRefresh());
  controls.push(await epochAcrossLoginCheck());
  controls.push(await fulfilledPageBoundary('request'));
  controls.push(await fulfilledPageBoundary('query'));
  guard.assertNoViolations(baseline, 'C independent VM controls');
  process.stdout.write(JSON.stringify({ fixedHead: '6fa36b5b60760d3d26fad2c95157954364e33e76', controls, networkGuard: 'no violations' }, null, 2) + '\n');
})().catch(error => { process.stderr.write(error.stack + '\n'); process.exitCode = 1; });
