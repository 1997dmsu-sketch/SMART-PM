from pathlib import Path
import hashlib, json, os, re, shutil, subprocess, tempfile
ROOT=Path('/workspace/SMART-PM-checkin-face-codex-r2')
OUT=Path('/workspace/artifacts/checkin-face-codex-r2-20261124')
ENV=dict(os.environ,NODE_OPTIONS='--require='+str(OUT/'review-network-guard.cjs'))
ENV.pop('NODE_TEST_CONTEXT',None)
owned=['scripts/checkin-face-static-check.mjs','scripts/verify-checkin-face-sources.mjs','tests/checkin-face-qa-gates.test.cjs','tests/checkin-face-cross-module.test.cjs','tests/support/d-network-guard.cjs']
hash_before={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in owned}
ignore=shutil.ignore_patterns('.git','node_modules','dist','.artifacts','.data','.cache','.env*','*.local.json','*.pem','*.pfx','*.key','project.private.config.json')
def copy(label):
 d=Path(tempfile.mkdtemp(prefix='d-falsify-'+label+'-',dir=OUT))
 shutil.copytree(ROOT,d,dirs_exist_ok=True,ignore=ignore)
 return d
def run(label,argv,cwd,expected):
 label += '-attempt2'
 p=subprocess.run(argv,cwd=cwd,env=ENV,capture_output=True,text=True,timeout=90)
 (OUT/(label+'.stdout.log')).write_text(p.stdout)
 (OUT/(label+'.stderr.log')).write_text(p.stderr)
 (OUT/(label+'.execution.json')).write_text(json.dumps({'argv':argv,'cwd':str(cwd),'NODE_OPTIONS':ENV['NODE_OPTIONS'],'exitCode':p.returncode},ensure_ascii=False,indent=2)+'\n')
 assert p.returncode==expected,(label,p.returncode,p.stdout[-3000:],p.stderr)
 return p
results=[]
# R10: restore the old lexical/window gate; only the new contract controls run.
d=copy('r10')
old=subprocess.run(['git','show','5398d1e:scripts/checkin-face-static-check.mjs'],cwd=ROOT,capture_output=True,check=True).stdout
(d/'scripts/checkin-face-static-check.mjs').write_bytes(old)
run('d-falsify-r10-syntax',['node','--check','scripts/checkin-face-static-check.mjs'],d,0)
p=run('d-falsify-r10',['node','--require',str(d/'tests/support/d-network-guard.cjs'),'--test','--test-reporter=tap','--test-name-pattern=^R10：(真实字段删除后多行块注释|分散假consent锚点)','tests/checkin-face-qa-gates.test.cjs'],d,1)
assert '# fail 2\n' in p.stdout
assert 'not ok 1 - R10：真实字段删除后多行块注释' in p.stdout
assert 'not ok 2 - R10：分散假consent锚点' in p.stdout
results.append({'control':'R10 old gate restored','copy':str(d),'exit':p.returncode,'failedAssertions':2,'meaning':'comment/decoy literals would again masquerade as request fields'})
# C1: restore stale-as-success in the formal frozen-tree case, keeping its new
# name so the real formal child case is selected by the regression test.
d=copy('c1')
qa=d/'tests/checkin-face-qa-gates.test.cjs'
s=qa.read_text()
oldqa=subprocess.run(['git','show','5398d1e:tests/checkin-face-qa-gates.test.cjs'],cwd=ROOT,capture_output=True,check=True,text=True).stdout
start=oldqa.index("test('C1：共享树清单校验")
end=oldqa.index("test('C1：未变更副本校验通过",start)
oldbody=oldqa[start:end]
oldbody=re.sub(r"test\('C1：共享树清单校验[^']*'", "test('C1：共享树冻结清单必须与磁盘一致，任何来源违规均失败关闭'",oldbody,count=1)
start=s.index("test('C1：共享树冻结清单")
end=s.index("test('C1：未变更副本校验通过",start)
qa.write_text(s[:start]+oldbody+s[end:])
run('d-falsify-c1-syntax',['node','--check','tests/checkin-face-qa-gates.test.cjs'],d,0)
p=run('d-falsify-c1',['node','--require',str(d/'tests/support/d-network-guard.cjs'),'--test','--test-reporter=tap','--test-name-pattern=^C1：源码漂移','tests/checkin-face-qa-gates.test.cjs'],d,1)
assert '# fail 1\n' in p.stdout
assert 'not ok 1 - C1：源码漂移' in p.stdout
assert '0 !== 1' in p.stdout
results.append({'control':'C1 stale-as-PASS restored','copy':str(d),'exit':p.returncode,'failedAssertions':1,'meaning':'the real formal QA child would accept the stale manifest'})
# S6: inject an actual premature executor callback into production orchestration.
# It uses the test's no-op synthetic executor; no real adapter is called.
d=copy('s6')
worker=d/'tools/checkin-face-worker/claim-and-enroll.mjs'
s=worker.read_text()
needle='      checkClaimTime(task, nowMs());\n      const authorized = await authorizeTaskExecution({ cloud, config, task, workerId });'
assert s.count(needle)==1
worker.write_text(s.replace(needle,'      await runEnrollmentImpl({}, { photoBuffer });\n'+needle,1))
run('d-falsify-s6-syntax',['node','--check','tools/checkin-face-worker/claim-and-enroll.mjs'],d,0)
p=run('d-falsify-s6',['node','--require',str(d/'tests/support/d-network-guard.cjs'),'--test','--test-reporter=tap','--test-name-pattern=^S6[bc] ','tests/checkin-face-cross-module.test.cjs'],d,1)
assert '# fail 4\n' in p.stdout
assert 'the actual main executor callback must remain untouched' in p.stdout
assert 'production main must never call the injected device executor' in p.stdout
results.append({'control':'S6 executor callback inserted before authority gates','copy':str(d),'exit':p.returncode,'failedAssertions':4,'meaning':'real main callback wiring detects forbidden execution in both expiry windows and after revocation'})
for p in owned:
 assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==hash_before[p],p
report={'results':results,'candidateOwnedHashesUnchanged':hash_before,'scope':'synthetic source copies only; no SDK init/device/listen/installation; outer review guard inherited'}
(OUT/'d-falsify-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
