# B 路独立只读复审

日期：2026-11-27，Asia/Shanghai。结论：**NEEDS_REVISION**。

本次发现 2 项 P1、2 项 P2。两项 P1 均是“不得在不可延长的任务/租期发送截止之后发出请求”的源码缺口，尚无真实超期发送证据；两项 P2 已以受网络保护的纯内存解析探针复现。未发现 P0。修正及定向离线回归完成前，不宜把当前实现描述成已满足严格绝对发送截止。

## 审查身份与对象

本审查者未参与实现；另由未参与实现的辅助审查者独立核对客户端截止和本机 Node 内嵌 HTTP 源码，未让其编辑或执行业务。

- worktree：`/workspace/SMART-PM-signed-remote-unlock-20261126`
- HEAD：`66e0395c105cda21244d375ef6d01682bc6cfe1e`
- 父提交：`2a45898aca74592a59a9d70e2f5b76e5c44cd51a`
- 分支：`feat/signed-lease-hikvision-remote-unlock-2026-11-26`
- 基线：`d798be60b2968a46cac22b6a5cdb25acc5e7b467`，已确认是 HEAD 的祖先。
- 初次及复核 `git status --porcelain=v1 --untracked-files=all` 均为空；没有替换 Git 对象或覆盖用户修改；`git replace -l` 为空。
- 检查了 `/AGENTS.md`、`/workspace/AGENTS.md`、worktree 根及 worktree 内各层，未找到适用的 AGENTS.md。
- 客户端 `miniprogram/config/runtime.js:6` 的 `allowDeviceOperations` 及第 7 行 `signedLeaseRemoteEnabled` 均为 false，未修改。

阅读范围：`admin-web/lib/hikvision-door.mjs`、`hikvision-client.mjs`，`tools/signed-remote-worker/**`（包括 CLI 包装、配置样例、README、依赖声明/锁和忽略规则），两份指定 worker/deadline 测试；对照实现卡 `docs/tasks/SIGNED-LEASE-HIKVISION-REMOTE-OPEN-IMPLEMENTATION-2026-11-26.md`，以及 `cloudfunctions/signedLeaseAccess` 的入口、task DTO、claimOpen/beginOpen/reportOpen 和授权/过期/单飞相关实现。

## 发现

### B-01 — P1：pin 放行后到真实 HTTP flush 仍有未核时的异步窗口

**位置：** `admin-web/lib/hikvision-client.mjs:58`、`:66`、`:334`、`:340`；覆盖缺口在 `tests/signed-remote-deadline.test.cjs:86` 至 `:88`。

**触发：** TLS/pin 恰在截止前完成，PinnedAgent 在第 58 行看到尚未到期，第 66 行将 socket 交给 Node。真实 Node 的 `ClientRequest.onSocket` 随后通过 `process.nextTick(onSocketNT)` 才附着 socket，并调用 `req._flush()` 写出已经由 `request.end(body)` 排队的 HTTP 字节。若交接至 nextTick 或其解析器初始化期间发生调度延迟/GC，使截止越过，当前代码没有在该实际 flush 边界再次核时。到期 timer 也要等待事件循环处理，不能抢先保证销毁。

**依据与限度：** 这是有运行时源码支持的静态推断，未对真实 TLS、socket 或设备动态复现。本机受支持的 Node v24.22.1 二进制内嵌源码可见 `setRequestSocket → req.onSocket → process.nextTick(onSocketNT) → tickOnSocket → req._flush`；`tickOnSocket` 在 flush 前发出 `socket` 事件。辅助审查者只读二进制所得关键换行位置为 83475–83481、84647–84657、84587–84621、84694–84696；这些是本机二进制内嵌文本位置，不是仓库源码行号。现有假 transport 在回调中同步 `request.flush()`，消除了真实的 nextTick 窗口，因此既有 4/4 不能排除此缺口。

**影响：** 可在任务 expiresAt（也可能正好是租期 validUntil）之后首次发出普通 open 或 Digest 认证请求。云端 fresh begin 和 pin 本身正确，也不能补上交接后的发送核时。

**最小修正：** 在 `request.end` 前注册真实 request 的 `socket` 事件，并在 Node flush 之前同步以同一不可延长截止核验，过期即销毁 request/socket；保留现有 pin 放行检查。若要求覆盖 flush 内部的阻塞，还应把最终防护落到实际写边界。未提供 absoluteDeadline 的旧调用保留原行为。

**验证建议：** 使用纯内存 transport 模拟真实的异步 onSocket/nextTick，令 pin 在截止前通过、交接后时钟到达截止，断言 request/body/Authorization 零字节写入；覆盖首发和 401 第二发。不要以同步 callback→flush 替代此用例，也无需真实网络。

### B-02 — P1：401 之间 wall clock 后退会延长同一逻辑请求的剩余发送预算

**位置：** `admin-web/lib/hikvision-client.mjs:262` 至 `:269`、`:281`、`:289` 至 `:291`、`:334` 至 `:339`，及 `:58`；worker 传入截止在 `tools/signed-remote-worker/worker-runtime.mjs:150`。

**触发：** 初发时 wall clock 为 T，绝对截止为 T+100ms。真实经过 50ms 时系统时钟回退 100ms；经过 60ms 收到 Digest 401，此时 Date.now() 为 T−40ms。首发完成会清除原 100ms timer，第二次 #send 重新算出 `(T+100)−(T−40)=140ms`，从真实第 60ms 再计时。认证 TLS 在真实第 120ms 完成时本机 wall clock 仍为 T+20ms，pin 放行核时也通过，因而可在原始 100ms 预算耗尽后发送。

**依据与限度：** 静态时序推导，未调整主机时钟、未跑网络实验。这是进程运行中的时钟回退问题，区别于部署时云端与主机初始时钟偏差；没有证据说明本环境已发生回退或真实超期发送。现有 deadline 测试只让 Date.now() 正向推进，没有独立 monotonic 时钟。

**影响：** 同一个 absoluteDeadline 数值虽然没改变，但其对应的真实剩余时长被认证重发重新延长；fresh begin 之后没有新的云端核时可以阻止该发送。

**最小修正：** 在接收/首次验证任务时锚定 epoch 与 monotonic 时间，形成不可增加的预算，并把同一预算贯穿准备、fresh begin 后最终检查、每个逻辑请求的首发/401 重发及 TLS/实际写边界；每次同时取 epoch 剩余量与原 monotonic 剩余量的较小值。不能仅在第二发重新使用 Date.now() 建预算。初始云/主机时钟可信度仍须部署核实。

**验证建议：** 纯内存中分开推进 wall clock 与 monotonic clock，按上述 401 时序令 wall clock 后退；原预算到期后即使 TLS pin 正确，也不得放行认证 body 或 Authorization。另覆盖回退发生于证书读取、型号 GET 与 begin 回执之间，确保不会重建更长任务预算。

### B-03 — P2：JSON 语法空白过宽，非法 JSON 能被判为 device_confirmed

**位置：** `admin-web/lib/hikvision-door.mjs:58`；另需留意 `:93` 的通用 trim，成功判定在 `:116` 至 `:121`。

**触发及本次证据：** 对公开解析函数输入以下 HTTP 200 合成 body（逗号后为实际 U+00A0）：

```text
{"statusCode":1,<U+00A0>"statusString":"OK","subStatusCode":"ok"}
```

原生 JSON.parse 拒绝该 body；自定义 reader 的 `/\s/` 将 U+00A0 当语法空白，返回 `{"status":"device_confirmed","deviceStatusCode":"1"}`。本次在加载既有 network fakes 和 no-forward guard 后，以 `node -e` 仅导入并调用纯 parser，已复现此输出；无 worker、SDK、网络或监听。

**影响：** 不完整/不受支持的协议语法没有降级到 unknown，而被对外记为设备已接受。它仍不等于物理门锁释放，但违反当前文档承诺的“Invalid/unsupported responses become unknown”。

**最小修正：** JSON 语法空白限定为 U+0020、tab、CR、LF；避免公共 trim 在语法校验前擦除其它非法首尾字符，或先对原始 UTF-8 文本执行严格 JSON 语法校验，再保留重复键拒绝逻辑。

**验证建议：** 在 token 之间及首尾分别放入 NBSP、垂直制表符、form feed 等非 JSON 空白，应全部 unknown；正常四种 JSON 空白仍接受，重复键继续拒绝。

### B-04 — P2：数组拒绝码穿透本地校验，导致唯一报告被云端拒绝并停止 loop

**位置：** `admin-web/lib/hikvision-door.mjs:116` 至 `:124`、`tools/signed-remote-worker/worker-runtime.mjs:168` 至 `:171`；云端严格类型边界为 `cloudfunctions/signedLeaseAccess/lib/service.js:460` 至 `:463`，适配器停止处理为 `worker-runtime.mjs:230` 至 `:233`。

**触发及本次证据：** 合法 JSON 但不符合协议字段类型的合成 body：

```json
{"statusCode":[2],"statusString":"Invalid Operation","subStatusCode":"notSupport"}
```

纯内存 parser 探针已返回 `{"status":"failed","deviceStatusCode":[2]}`。原因是正则 test 隐式把数组 [2] 转成 "2"，但随后返回的 code 仍是数组。worker 对 failed 码也用同样的正则而没有 typeof 检查，静态可见它继续提交该数组；真实 reportOpen 则要求拒绝码为 string，返回 INVALID_INPUT。适配器会把该码设为 stopLoop，唯一报告未入库。

**影响：** 不受支持的设备回执被本地标为 failed，报告被拒绝，云任务保留 executing（到期后 unknown），轮询停止；需要人工诊断，且当次应报告的 unknown 事实丢失。未发现此路径会清除云端 unknown 单飞或重发 open。

**最小修正：** parser 只接受明确的数字/字符串 statusCode 并统一成闭合字符串集合；数组/对象/其它类型一律 unknown。worker 对 provider 的 `deviceStatusCode` 再做独立、显式 string/null 类型校验，拒绝数组穿透，不依赖正则隐式转换。

**验证建议：** 覆盖 [2]、[[2]]、["2"]、对象和其它非标量类型；均形成一次 `status:unknown, deviceStatusCode:null` 报告，不因本地生成的非法 payload 停止 loop，不增加 open 次数。

## 已静态确认的保护与契约

- 自动资格来自已确认签约，资格生成不调用 provider；租客 requestId 持久去重。任务上界 `expiresAt=min(timestamp+30000,validUntil)`，validUntil 为排他租期上界（service.js:397）。
- cloud claim 仅领取 queued，begin 只从 claimed CAS 到 executing，重读 worker revision、合同/资格/绑定/程序 revision、本人和租期（service.js:416–455）；设备 I/O 不在云事务回调内。
- worker 拒绝任务额外字段、目标/门号/型号不符和超期；公开证书受限普通文件读取；实读 deviceInfo 型号之后才 fresh begin，并核同一快照仅 revision+1（worker-runtime.mjs:74–104、:146–166）。
- worker 固定 developmentTls:false，客户端保留正常 CA/hostname 与 SPKI pin，pin 验证前不交出 socket。没有发现将 timeout/unknown/5xx 作为业务重发条件；仅 401 最多认证重发一次。逻辑 open 数不等于 TCP/HTTP 发送数。
- provider 只发固定普通 open，await 前消耗实例；known device receipt 不代表现场锁释放。未知状态在云端保留 grant 单飞，旧 executing/unknown 不重排为 queued。
- processOnce 在无有效 begin 回执时不编造报告；known outcome 在 provider close 抛错后仍尝试唯一报告。cleanup 标志使执行非零并停止 loop，早期主失败码得到保留（worker-runtime.mjs:175–190、:306）。未发现真实 close 错误遮蔽主失败并伪造成功的路径。
- loop 串行 await 每条完整处理，再领取下一条；本地 consumed claim 截止后才清理，云端单次 begin/终态承担跨进程排他。未发现可由普通云任务注入 URL/XML/凭据/常开常闭或证书路径的路径。
- SDK 入口约束在显式本地边界，校验固定包名/3.18.7 与入口 realpath，禁止祖先 fallback；默认/help/config-check 不 import/init SDK。秘密、origin、证书路径不进入 CLI 白名单摘要或 raw error 输出。未发现所审输出路径泄露真实材料。

## 验证记录与未验证项

本次未执行任何现有测试套件、610/CR2/EOF/WP06、打包、依赖安装或 CLI 执行模式；未启动 worker 或监听；未访问真实 TLS/云/设备/账号/支付/凭据；未改变功能开关。仅写本报告。第一次以 stdin 运行同一纯解析探针时，既有 guard/fakes 与 Node stdin bootstrap 不兼容而在业务导入前失败；改用 -e 后两条合成解析探针 exit 0，输出见 B-03/B-04。

只读查看了既有 `/workspace/artifacts/signed-remote-unlock-2026-11-26/client-deadline-tests.log`（历史 4/4）、`worker-cleanup-tests.log`（历史 22/22），以及 `package-attempt-01/package.execution.json` 和 stdout/stderr（记录该 HEAD 的历史离线 package exit 0/610）。这些不是本审查者复跑，不能当作新增覆盖；现有用例没有 B-01/B-02 时序，也未覆盖 B-03/B-04 的输入。

真实云事务/SDK 响应、IAM/私有集合规则、索引、可信证书链/主机名、实际 pin/型号/门号、主机与云端时钟初始可信度、真实设备协议响应以及现场门锁释放均未验证。它们是实施卡明确保留的部署/验收前置，本报告不将缺少真实验收推断为已发生漏洞，也不批准上线、开开关或真实开门。
