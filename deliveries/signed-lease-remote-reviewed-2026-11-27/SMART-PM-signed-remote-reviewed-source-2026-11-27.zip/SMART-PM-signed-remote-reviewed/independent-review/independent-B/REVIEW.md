# B 路原独立会话：退修复验

日期：2026-11-27，Asia/Shanghai。结论：**PASS（仅 B-01 至 B-04 退修源码及相关纯合成回归）**。

| 原项 | 原级别 | 本次状态 |
|---|---|---|
| B-01：pin 后异步 socket 交接/flush 窗口 | P1 | CLOSED |
| B-02：wall clock 后退延长 401 预算 | P1 | CLOSED |
| B-03：非法 JSON 空白误判成功 | P2 | CLOSED |
| B-04：数组拒绝码穿透并污染 report | P2 | CLOSED |

本次未发现这四项修正引入的残余 P0–P3 问题。独立正向复验 37/37、退出码 0；在自有副本对旧源码做的 11 项最小负控全部按预期失败、退出码 1。PASS 不代表真实 TLS、云端、设备或物理门锁验收，也不批准部署、打开开关或设备操作。

## 固定对象、范围与原件

续用原独立 B 审查会话；本审查者及原辅助审查者均未参与修复。

- worktree：`/workspace/SMART-PM-signed-remote-review-fix-20261127`
- HEAD：`6fa36b5b60760d3d26fad2c95157954364e33e76`
- 直接父：`66e0395c105cda21244d375ef6d01682bc6cfe1e`
- 分支：`fix/signed-remote-independent-review-2026-11-27`
- 初次与完成前工作区状态均 clean；差异恰为 13 文件。适用祖先和 worktree 各层未找到 AGENTS.md。未编辑被审源码、提交或替换 Git 对象。
- 原 B 报告仍为 12787 字节，SHA-256 `f781577135bdb63e90a4a97ec072c68410268591a18b8818cfa29b122db93f93`，保持原字节。
- 已读原 B 报告及 `docs/tasks/SIGNED-LEASE-HIKVISION-REMOTE-OPEN-REMEDIATION-2026-11-27.md`。仅复验 B 四项与关联回归；A/core 未重开，C 的业务修复由原 C 另行复验。
- 13 文件中的版本/来源 hash/退修卡作为配套变更核对：root 与小程序均为 `0.1.0-beta.22-signed-lease-remote-source.2`；修改文件中已登记的来源 hash 与当前字节一致。两项真实功能开关仍为 false。完整对象信息及 13 文件清单见 `audit-object.json`。

## 逐项关闭依据

### B-01 — CLOSED

`admin-web/lib/hikvision-client.mjs:365` 在 `request.end:389` 之前装入 request 的 `socket` 监听。第 372 行在实际异步交接后重新核验同一截止；第 376–378 行包裹最终应用层 `socket.write`，再次核验后才调用原 write，并保留 this 与全部参数。第 367–370 行超期路径拒绝 promise 并销毁 request/socket。原先的 pin 放行检查仍在第 71 行，正常 CA/hostname 与 SPKI 校验未降低。

**真实 Node 时序的只读核对：** 本次在 Node v24.22.1 读取内嵌源码，未调用 transport。保存于 `node-http-order.raw.log`：
- `_http_agent:716–717`：setRequestSocket 调用 req.onSocket。
- `_http_client:1150–1160`：onSocket 使用 process.nextTick(onSocketNT)。
- `_http_client:1090–1124`：tickOnSocket 完成初始化并 emit('socket')。
- `_http_client:1198–1199`：tickOnSocket 后才 req._flush()。
- `_http_outgoing:1325–1335`：flush 对 socket cork，然后逐块 socket.write，最后 uncork。

因此新 socket 监听确实位于 Node 的 flush 之前，write 包裹也覆盖 flush 内部延迟后才调用 write 的情况。不能仅凭 fake 测试作出这个 Node 顺序结论。

**独立动态证据：** `tests/signed-remote-deadline.test.cjs:198`、`:217`、`:238` 三项通过：pin 在截止前成功，下一 tick 越过截止时首发/401 认证字节为 0；已进入模拟 flush 后再到截止也不调用底层 write。测试 transport 在第 74–91 行明确保留 nextTick→socket event→flush 的间隔，未恢复原同步 handoff 假设。旧三源文件副本上的这三项分别失败，证明断言对原缺口敏感。

**边界：** 这里核验的是应用调用 TLSSocket.write 的最后受控交接点。Node/TLS 可缓冲已接受的字节，之后的 uncork、TLS/内核发送、网络到达和设备执行时刻没有被本测试测量或保证；代码不承诺撤回已经接受的字节。该边界与退修卡第 23 行一致。

### B-02 — CLOSED

`tools/signed-remote-worker/worker-runtime.mjs:132–137` 在 claim 首次校验时一次采样并固定 monotonic 预算；第 139–144 行始终取 epoch/原 monotonic 剩余量的较小值。证书后、第 173 行型号读取前、第 176 行 GET 后、第 183 行 begin 回执后均核验；第 168 行将原 budget.deadline 传给 client，没有在准备或 begin 后重建预算。

`admin-web/lib/hikvision-client.mjs:249–254` 保留 worker 提供的预算；仅 absoluteDeadline 的直接调用在构造时锚定一次，且在证书解析前锚定。第 290–296 行为同一逻辑请求选取不可增加的预算，首发和 401 原样共用；第 31–38 行、TLS 第 71/86 行、发送第 316/383 行及 socket/write 各门都检查两种时钟。未带 absoluteDeadline 的旧调用不安装新增发送门，保留其旧超时语义。

**独立动态证据：** deadline suite 第 253、275、292、315 行用分开的 wall/monotonic 时钟覆盖 401/TLS 回退、pin 后异步交接和 write、absolute-only 构造锚点、构造前耗尽及旧无截止调用。worker suite 第 201–239 行覆盖证书、型号 GET 和 begin 阶段 wall 回退后耗尽原预算，open 均为 0，并确认 cloud TASK 不可注入 monotonicDeadline。这些用例本次均通过；旧源码副本上对应五项负控失败。

**未验证前提：** 初始主机/云端时钟偏差与可信度仍需部署核实。进程内 performance.now 预算不能证明工作机在首次采样时已与云端同步；本次没有修改系统时钟或用真实时钟漂移实验替代该前提。

### B-03 — CLOSED

`admin-web/lib/hikvision-door.mjs:12` 使用明确 ASCII 语法 trim；第 61 行只接受 SP/HTAB/CR/LF；第 96 行保留原 UTF-8 文本，第 103–104 行分流后仍对原文做 JSON 解析。非法首尾空白不会先被通用 trim 擦除。XML 语法也采用明确空白限制，重复键和不支持结构仍失败关闭。

**独立动态证据：** `tests/signed-remote-worker.test.cjs:135–152` 覆盖 NBSP、VT、FF、BOM、多种 Unicode 空白在 JSON 首尾/内部及 XML 相关边界的 unknown 结果，四种合法 JSON 空白有正向控制，重复键仍拒绝。本次通过；旧源码副本中的同一项失败，并再次显示非法空白可被旧实现识别为 device_confirmed。

### B-04 — CLOSED

`admin-web/lib/hikvision-door.mjs:119–121` 先限定 statusCode 为 number/string 标量，再统一到闭合字符串；数组/对象等在转换前就返回 unknown。`tools/signed-remote-worker/worker-runtime.mjs:189–192` 对 provider failed 码独立执行显式 string/null 检查；非法值转换为 unknown/null 后走第 206–208 行唯一报告，不再产生数组 payload。

**独立动态证据：** `tests/signed-remote-worker.test.cjs:155–167` 验证 [2]、[[2]]、["2"]、对象、布尔、null、非整数等输入拒绝，以及合法 number/string 归一；第 169–198 行绕过 parser 向 worker 注入非字符串拒绝码，确认一次 open、一次合法 unknown/null 报告、不停止 loop、重复 claim 不再 open/report；合法 null/"2"/"7" 仍正常回报。本次两项通过；旧源码副本的两项负控失败。

报告接收方是纯合成替身，未访问真实云端。payload 类型关闭另由上述代码静态确认；没有把 fake 接收成功称作云服务验收。

## 本次独立命令与原样证据

实际工作目录为固定新 worktree，Node v24.22.1。预载的是原 no-forward guard，未预载 socket constructor fakes 到父 runner，未修改 guard。

```text
node --require ./tests/support/d-network-guard.cjs --test tests/signed-remote-deadline.test.cjs tests/signed-remote-worker.test.cjs
```

独立结果：**37 tests / 37 pass / 0 fail / exit 0**，其中 deadline 11 项、worker 26 项。原样 stdout/stderr 合并保存，无删改：

| 证据 | 字节 | SHA-256 |
|---|---:|---|
| independent-tests.raw.log | 3916 | 0bcbbd481bdc7fd3e0c3b2ea77dfc630bdfa4a5caf2e8f3697ac8940938e3aa7 |
| negative-control.raw.log | 29919 | fa8ff4bc495e78e38026081f6346cbc1e856ad2847c4ecb1265b0e71fec3e01d |
| node-http-order.raw.log | 6402 | 2aa07f51d09fa2770367617cb5a5bac54a192b8f79a818b6b8908bf59e21bdca |

命令 argv、cwd、开始/结束时间和真实退出码在 `independent-tests.execution.json`；可直接复制的命令另存 `independent-tests.command.txt`。Node 源码只读提取的完整 argv 与 exit 0 在 `node-http-order.execution.json`。

**最小负控：** 只在本报告目录的 `negative-control-original-sources/` 中，使用 git show 读取父提交的 client/door/worker 三文件，与本修订的测试、guard 和合成证书配对。没有改被审源码或旧 worktree。来源和逐文件 SHA-256 保存为 `negative-control.manifest.json`。

```text
node --require ./tests/support/d-network-guard.cjs --test --test-name-pattern '^B-0[1-4]' tests/signed-remote-deadline.test.cjs tests/signed-remote-worker.test.cjs
```

副本内结果：**11 tests / 0 pass / 11 expected fail / exit 1**。B-01 三项、B-02 五项、B-03 一项、B-04 两项均触发原缺陷断言；失败不是装配/导入/guard/bootstrap 故障，也不是对修订 SHA 的失败结论。原始命令与退出码见 `negative-control.command.txt`、`negative-control.execution.json`。所有工件（含原样日志、副本来源清单和本报告）的 SHA-256 汇总见 `SHA256SUMS`。

原修复方 `B/send-after.log` 与 `B/parser-worker-after-01.log` 仅作为继承证据只读查看，未把它们称为本次独立运行。旧 610、原 4/4 和 22/22 不作为新修订验证结论。本次没有重跑 610/CR2/EOF/WP06、全量 npm、打包或安装依赖。

## 退出边界

本次仅写专属工件目录；被审 worktree 与原报告保持不变。未执行真实 worker CLI、SDK 真实初始化、真实 TLS/云/设备/账号/支付/凭据访问、监听、部署或开关变更。测试中涉及 provider/SDK/CLI 的路径均为既有合成替身或依赖注入，不是实环境执行。

真实证书链/主机名/SPKI、设备型号与门号、云事务/权限/规则、初始时钟可信度、设备响应兼容性及现场物理释放仍未验证。`device_confirmed` 只表示支持的协议确认，不等于门锁已释放。B 四项已完成离线关闭，现停手交主 Codex 汇总，不批准后续真实操作。
