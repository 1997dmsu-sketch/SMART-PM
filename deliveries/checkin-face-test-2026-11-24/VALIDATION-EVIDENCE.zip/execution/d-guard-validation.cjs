'use strict';
const assert = require('node:assert/strict');
const {spawnSync} = require('node:child_process');
const modules = ['net','tls','http','https','dgram','dns','dns/promises'];
const saved = modules.map(name => {
  const object = require('node:' + name);
  const entries = Reflect.ownKeys(object).map(key=>[key,Object.getOwnPropertyDescriptor(object,key)]);
  const prototypes = [];
  for (const key of Reflect.ownKeys(object)) {
    const d=Object.getOwnPropertyDescriptor(object,key);
    if (typeof d?.value === 'function' && d.value.prototype) {
      const p=d.value.prototype;
      prototypes.push([p,Reflect.ownKeys(p).map(k=>[k,Object.getOwnPropertyDescriptor(p,k)])]);
    }
  }
  return {object,entries,prototypes};
});
const globalDescriptors = ['fetch','WebSocket','EventSource'].map(k=>[k,Object.getOwnPropertyDescriptor(globalThis,k)]);
const options = process.env.NODE_OPTIONS;
const guard = require('/workspace/SMART-PM-checkin-face-codex-r2/tests/support/d-network-guard.cjs');
(async()=>{
  assert.equal(guard.assertLoadTimeClean().blocked,0);
  const self=guard.selfTest();
  assert.equal(self.ok,true);
  assert.equal(self.attempts,guard.patchedCount);
  assert.equal(self.caught,self.attempts);
  assert.equal(self.blockedDelta,self.attempts);
  assert.equal(self.forwarded,0);
  assert.equal(guard.selfTest().ok,true);
  assert.equal(guard.loadTimeSnapshot().blocked,0);
  const esm=await guard.verifyNamedBindings();
  assert.equal(esm.ok,true);
  const snap=guard.snapshot();
  guard.assertNoViolations(snap,'safe-window');
  let getterCalls=0;
  const target={get host(){getterCalls++; throw Error('GETTER');}};
  assert.throws(()=>require('node:http').request(target),e=>e.code==='D_NETWORK_GUARD_BLOCKED');
  assert.equal(getterCalls,0);
  assert.throws(()=>guard.assertNoViolations(snap,'blocked-window'),e=>e.code==='ERR_ASSERTION');
  const child=spawnSync(process.execPath,['-e',`const g=globalThis.__DSH_D_NETWORK_GUARD__;if(!g)process.exit(3);g.assertLoadTimeClean();const s=g.selfTest();if(!s.ok)process.exit(4);process.stdout.write(JSON.stringify({inherited:true,slots:g.patchedCount,blocked:s.blockedDelta,forwarded:s.forwarded}));`],{encoding:'utf8'});
  assert.equal(child.status,0,child.stderr);
  assert.equal(JSON.parse(child.stdout).inherited,true);
  const restored=guard.restore();
  assert.equal(restored.ok,true);
  for(const {object,entries,prototypes} of saved){
    assert.deepEqual(Reflect.ownKeys(object),entries.map(([k])=>k));
    for(const[k,d]of entries)assert.deepEqual(Object.getOwnPropertyDescriptor(object,k),d);
    for(const[p,ds]of prototypes){assert.deepEqual(Reflect.ownKeys(p),ds.map(([k])=>k));for(const[k,d]of ds)assert.deepEqual(Object.getOwnPropertyDescriptor(p,k),d);}
  }
  for(const[k,d]of globalDescriptors)assert.deepEqual(Object.getOwnPropertyDescriptor(globalThis,k),d);
  assert.equal(process.env.NODE_OPTIONS,options);
  for(const name of modules){const ns=await import('node:'+name);const object=require('node:'+name);for(const key of Object.keys(ns)){if(key!=='default'&&typeof object[key]==='function')assert.equal(ns[key],object[key]);}}
  process.stdout.write(JSON.stringify({ok:true,slots:guard.patchedCount,self,esm,child:JSON.parse(child.stdout),restored})+'\n');
})().catch(e=>{console.error(e);process.exitCode=1;});
