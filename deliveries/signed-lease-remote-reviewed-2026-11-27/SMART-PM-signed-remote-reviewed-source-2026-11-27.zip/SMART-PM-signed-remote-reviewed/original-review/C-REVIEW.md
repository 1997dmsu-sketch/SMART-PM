# C 路独立只读复审

结论：**NEEDS_REVISION**。未发现本范围未关闭的 P0/P1/P2；独立确认 1 个 P3（C-01，旧登录回调会取消当前新登录的确认操作）。本结论是固定源码的独立复审，不是部署、微信真机或真实云/设备验收。

审查日期：2026-11-27，Asia/Shanghai。审查者未参与本次实现；后台边界另由一个只读子审查交叉核对。

## 审查对象与执行边界

- 工作区：`/workspace/SMART-PM-signed-remote-unlock-20261126`。
- HEAD：`66e0395c105cda21244d375ef6d01682bc6cfe1e`。
- 父提交：`2a45898aca74592a59a9d70e2f5b76e5c44cd51a`。
- 分支：`feat/signed-lease-hikvision-remote-unlock-2026-11-26`。
- 比较基线：`d798be60b2968a46cac22b6a5cdb25acc5e7b467`。
- 初始、复核末尾均 `git status --short --branch` 仅输出上述分支，源码工作区 clean；没有替换审查对象、切换分支或修改源码。
- 检索 `/AGENTS.md`、`/workspace/AGENTS.md`、仓库及 `/workspace/.agents`、`/workspace/.codex` 的适用 `AGENTS.md`，未发现文件。
- 只读检查 mini API、unlock JS/WXML/WXSS、runtime/version；后台 facade、新 routes、页面及 index 导航；新增 frontend/admin tests；追踪 signedLeaseAccess 所有公开 action/DTO、可信上下文、身份/手机号证明及后台数据库适配路径。
- 本次只执行 1 个离线内存 VM 场景，不运行全量测试；没有安装、启动 HTTP/UI/worker、访问真实云/设备/支付/凭据、提交或推送。写入范围仅本 C 报告目录。没有重开 CR2/EOF/D/E/WP06。

## 发现

### C-01 / P3：旧账号迟到回调会清掉新账号当前确认操作

准确位置：

- `miniprogram/pages/unlock/index.js:216`：旧 requestOpen 拒绝回调先调用 `canUsePrivate(loginEpoch)`。
- `miniprogram/pages/unlock/index.js:95`：预期 epoch 不匹配时，`canUsePrivate` 无条件调用 `clearPrivate()`。
- `miniprogram/pages/unlock/index.js:75`：`clearPrivate` 释放的是此刻页面的 `_unlockOperation`；`:76` 推进当前视图版本，`:79` 清空当前门锁等内容。
- 同类 query 完成路径位于 `miniprogram/pages/unlock/index.js:252`、`:258`。
- `miniprogram/services/api.js:34`、`:29` 正确拒绝旧登录回执，所以真实 API 的正常结果也会转入页面的上述 catch。

触发条件：A 登录发起签约开门，云调用尚未返回；退出后登录 B，返回同一 unlock 页面；B 已加载本人门锁并打开新的确认窗口；此时 A 的旧云回执到达。A 的 API 回执按 epoch 被拒绝，但页面处理拒绝时清理了 B 当前操作。B 再点击原确认窗口“确认开门”时，操作对象已失效，因此不提交 B 的请求。

影响：旧异步工作可以取消当前新登录的有效确认窗口、清空当前门锁列表并造成无提示的不执行，用户须重新加载并操作。未观察到旧账号信息回填、越权或重复开门；因此定为 P3。此问题与已修的同 epoch 跨 await 双 modal P2 不同，不重开原 P2。

最小修正：在 signed request/query 完成路径先做无副作用的 epoch/状态所有者比较，过期回调直接丢弃。若保留统一 `canUsePrivate`，应区分“当前已无有效登录”与“仅旧回调期望 epoch 失效”；后者不得清理另一个有效登录拥有的视图或 `_unlockOperation`。保留当前未登录清隐私、同 epoch hide/show 接收回执及操作对象所有权检查。

建议验证：加入 A 请求/查询未完成 → B 登录并打开确认 → A 成功或失败迟到 → B 操作仍持锁且确认恰好提交一次的测试；再覆盖 B 已进入 requestOpen、旧 query finally 晚返及 logout 后仍应清私密数据。验证旧结果绝不替换 B 状态、旧 finally 不释放 B operation。

本次独立验证：直接以磁盘中的真实 `api.js`、`require-login.js`、unlock 页面源码装载 VM，注入内存 WX cloud/profile/door/modal；预载现有 D 网络守卫。仅执行上述一个场景，退出 0，守卫无违规；断言的是缺陷确实发生，不计作套件通过。观察结果：

```json
{
  "before": { "confirming": true, "operationOwned": true, "locks": 1, "epoch": 3 },
  "afterOldReceipt": { "confirming": false, "operationOwned": false, "locks": 0, "signedOpen": null, "epoch": 3 },
  "signedCallsAfterBConfirm": 1,
  "guard": "no violations"
}
```

最后的 1 次 signed 调用是 A 的原请求；B 确认后没有新增调用。内存返回均为合成数据，没有任何真实发令。

## 其余已核结果

- 后台新路由位于既有 Origin（`admin-web/server.mjs:145`）、session/当前账号 revision（`:158`、`:170`、`:236`）、CSRF（`:237`）守卫后；`:301` 显式仅允许 admin，editor/viewer 不能进入，`:332`、`:337` actor 取会话 `account._id`，不接收请求自报 actor/role。
- record GET 在 `server.mjs:327` 拒未知或重复 query key；facade `admin-web/lib/signed-lease-administration.mjs:127` 再作闭式 kind/id 校验；core `cloudfunctions/signedLeaseAccess/lib/service.js:220` 至 `:241` 仅固定集合点读，不调用 expire/put/audit。响应仅固定 DTO 字段；不返回签约证据、手机号证明、worker hash/token、claim 或设备凭据。GET 不推进任务超时或释放占用。
- 后台 `live` 在 `server.mjs:314` 使用 `TenantAuthCloudDatabase`；`demo` 使用 `LocalCloudDatabase`。管理 SDK adapter `admin-web/lib/tenant-auth-cloud-database.mjs:22` 去除 `_id` 并把 wx 风格 `{data}` 转为管理 SDK record，`:70` 保留底层 `runTransaction`。本地 MVCC、mock SDK 和真实云事务是不同证据层级；未声称真实 SDK/云联调完成。
- 后台页面住户/房屋从已验证住户与现有 rooms 选择列表获得，房门、租期、证据及版本均需明确输入；没有默认住户、102、门 1、租期或示例设备。提交前 `admin-web/public/signed-lease-access.js:181` 设置 busy，跨 await 保留；401/适用403锁页、清查询与回执，使用 textContent 输出；未自动重试、自动填表或启用开关。
- 云 `createMain` 的 action/字段闭式；管理员来自 `verifiedAdmin(sdk.getWXContext())`，租客来自可信 WX 上下文，不接受客户端 actor/userId/手机号/房屋/租期授权字段。后台调用相同 core 的 actor 由后台会话授权派生。签约 core 同一事务写 contract/grant/user access/audit，不把手机号注册、face/payment 或旧 `users.houses` 当新资格前置。
- 租客 API 的 listDoors/requestOpen/getOpenResult 与云 DTO 字段吻合；输出投影去除服务端秘密；日期直接显示服务端 `startDate/endDate`（`miniprogram/services/api.js:252`），不按客户端时区重算；未知 reason 不可开门。服务端关闭/租期/资格仍逐次核验。
- 新海康门禁明确标记 `signed_lease`，禁止落入 legacy unlock；云 legacy 显式未知平台拒绝，未发现新通道绕入旧 public/houses/admin 授权。请求入队、执行中、unknown、device_confirmed 的文案区分明确；设备接受没有写成现场门锁已释放。
- 原 P2 的跨 await 确认锁已实际读至当前实现：页面 `:168` 取得 operation 对象，`:196` 阻重复 callback，`:202` 再核对象所有者；旧 modal fail/cancel 不能释放新 owner。没有仅凭提交标题认定修复，也没有发现该同 epoch 路径的残余双发触发条件。
- 同 epoch hide/show 的 signed request 回执可保留并在可见时同步；query 用序号及 task/request 身份比较阻止旧结果覆盖新显式请求。onUnload 后不显示结果。不同 epoch 旧结果不恢复旧账号数据，但存在 C-01 的新视图清理副作用。
- 未收到提交回执时进入 unknown、没有 taskId 的页面只指向管理员核查且不补发；已得到 taskId 的同一任务可手动查询。服务端相同 requestId 返回既有任务且不重入队。`resolved` 必须为服务端 boolean，unknown 只有 true 才允许下一次显式确认；处置不伪称原开门已成功。
- `miniprogram/config/runtime.js:6` 的 `allowDeviceOperations=false`、`:7` 的 `signedLeaseRemoteEnabled=false`；core `service.js:153` 缺程序配置返回 enabled/dispatchEnabled false。版本明确“源码候选；未部署或设备验收”。没有变更这些默认关闭状态。

## 继承证据与未核范围

以下均只读查阅，不是本审查独立复跑。相应 exit-code 文件均为 0；不同阶段用例数量不应相加或表述为本次通过数。

| 继承文件（相对 `/workspace/artifacts/signed-remote-unlock-2026-11-26/`） | 观察到的结果 | 字节数 | SHA256 |
| --- | --- | ---: | --- |
| `frontend/modal-lock-targeted-tests.log` | 53/53，含跨 await 锁及旧 modal 回调 | 5172 | `618f35df0c4f97ed78538c7567fbbcea381965c454cda863607552ebea757deb` |
| `frontend/page-race-targeted-tests.log` | 51/51，含 hide/show、旧 epoch、旧 query | 4945 | `1c624800d1d83494b3ee5bb6cda7be2924f9835b15ee7a37a43797332e9f2f68` |
| `frontend/server-dates-targeted-tests.log` | 48/48，含服务端日期 | 4664 | `e85d505372db66be64307fea8c3bf0c88e3b051da5229a482211519b0f404ba9` |
| `frontend/admin-record-tests.log` | 16/16，含 GET、页面与后台边界 | 2032 | `3713df9e4ab18378d76310617b05dd52ba921753e18f3e5036d04592f0307e2b` |
| `package-attempt-01/package.execution.json` | 记录固定 HEAD，打包命令退出0，离线合成范围 | 666 | `1ff0d036f7eeeceb3e197577907fff6ff36a397204a56148dd7a710a504189f3` |

另查 `package.stdout.raw.txt`，其 610/610 是既存合成结果，未据此认定本审查独立执行610或真实环境可用；`package.stderr.raw.txt`/execution metadata 同属继承材料。

未核：真实管理 SDK 和微信云事务行为/IAM/索引/集合客户端规则的部署事实，真实后台账号与租户数据，微信开发者工具/真机生命周期和平台上传，公网/局域网设备 TLS/型号/门号/物理响应，支付、合同真实签署与法律效力，CR2/EOF/D/E/WP06 与全库其它 writer 的完整正确性。未把代码存在等同已部署小程序，未验证或操作真实凭据。

本轮到此停手；未实施 C-01 修正，交主 Codex 统一处理。
