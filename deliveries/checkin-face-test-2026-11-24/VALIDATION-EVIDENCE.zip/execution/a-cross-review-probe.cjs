'use strict';
// Independent synthetic cross-review. Reuse only the MemoryDB and public-API
// fixtures before the first test registration; no test suite is started.
// No SDK, real credentials, cloud/device I/O, deployment, or candidate writes.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const { createRequire } = require('node:module');
const { createHash } = require('node:crypto');
const ROOT = '/workspace/SMART-PM-checkin-face-codex-r2';
const testFile = path.join(ROOT, 'tests/checkin-face-cloud-workflow.test.cjs');
const source = fs.readFileSync(testFile, 'utf8');
const firstTest = source.indexOf("\ntest('");
assert.ok(firstTest > 0);
const box = { require: createRequire(testFile), __dirname: path.dirname(testFile),
  __filename: testFile, module: { exports: {} }, exports: {},
  Buffer, Date, console, setTimeout, clearTimeout, structuredClone };
vm.runInNewContext(source.slice(0, firstTest) + `\nmodule.exports = {
 fixture, approvedFixture, queuedFixture, claimedFixture, claim, begin,
 fileId, successOutput, ENV, COLLECTIONS, ids, STATUS, TOKEN, WORKER_ID,
 NAMESPACE, OTHER_NAMESPACE, JPEG, OPENID,
};`, box, { filename: testFile });
const F = box.module.exports;
const codeFiles = ['cloudfunctions/checkinFaceTest/lib/workflow.js',
  'cloudfunctions/checkinFaceTest/lib/context.js', 'cloudfunctions/checkinFaceTest/lib/validate.js',
  'admin-web/lib/checkin-face-test-config.mjs'];
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex');
const codeHashes = () => Object.fromEntries(codeFiles.map((name) => [name, hash(fs.readFileSync(path.join(ROOT, name)))]));
const beforeCodeHashes = codeHashes();
const snapshot = (ctx) => structuredClone([...ctx.db.collections].map(([name, rows]) => [name, [...rows]]));
const results = [];
function deferred() { let resolve; const promise = new Promise((r) => { resolve = r; }); return { promise, resolve }; }
async function limited(promise) { let timer; try { return await Promise.race([promise,
  new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('synthetic barrier timeout')), 5000); })]);
} finally { clearTimeout(timer); } }
const report = (ctx, task, exitCode, output, revision = task.revision) => ctx.main({ action: 'reportTask',
  workerToken: F.TOKEN, taskId: task.taskId, claimId: task.claimId, revision, exitCode, output });
async function check(name, run) { await run(); results.push({ name, result: 'PASS_SYNTHETIC_ONLY' }); }

(async () => {
  await check('namespace-changed-during-download-fails-authoritative-transaction-with-zero-write', async () => {
    const ctx = await F.approvedFixture();
    const entered = deferred(), released = deferred();
    ctx.cloud.downloadFile = async () => { entered.resolve(); await released.promise; return { fileContent: F.JPEG }; };
    const creating = ctx.main({ action: 'createFaceTask', applicationId: ctx.applicationId,
      fileId: F.fileId(ctx.applicationId), consent: true });
    await limited(entered.promise);
    await ctx.admin.setStorageNamespace(F.OTHER_NAMESPACE);
    const before = snapshot(ctx);
    released.resolve();
    const result = await creating;
    assert.equal(result.code, 'FILE_NAMESPACE_MISMATCH');
    assert.deepEqual(snapshot(ctx), before);
  });
  await check('concurrent-namespace-setter-does-not-resurrect-committed-disable', async () => {
    const ctx = await F.fixture();
    const paused = deferred(), resume = deferred();
    let once = true;
    ctx.db.beforeCommit = async () => { if (once) { once = false; paused.resolve(); await resume.promise; } };
    const saving = ctx.admin.setStorageNamespace(F.OTHER_NAMESPACE);
    await limited(paused.promise);
    await ctx.admin.setSwitch(false);
    const disabled = ctx.db.row(F.COLLECTIONS.CONFIG, F.ids.configId(F.ENV));
    resume.resolve();
    await saving;
    const final = ctx.db.row(F.COLLECTIONS.CONFIG, F.ids.configId(F.ENV));
    assert.equal(final.enabled, false);
    assert.equal(final.storageNamespace, F.OTHER_NAMESPACE);
    assert.equal(final.revision, disabled.revision + 1);
    assert.ok(ctx.db.commitLog.some((row) => row.outcome === 'conflict-retry'));
    assert.notEqual((await ctx.apply()).data?.result, 'auto_approved');
  });
  await check('configuration-commit-failure-rolls-back-business-and-audit', async () => {
    const ctx = await F.fixture();
    const before = snapshot(ctx);
    ctx.db.failCommits = 1;
    await assert.rejects(() => ctx.admin.setStorageNamespace(F.OTHER_NAMESPACE), (e) => e.code === 'SIMULATED_COMMIT_FAILURE');
    assert.deepEqual(snapshot(ctx), before);
  });
  await check('claimed-success-refused-but-closed-preexecution-failure-recorded', async () => {
    const ctx = await F.claimedFixture(), task = ctx.task;
    const before = snapshot(ctx);
    assert.equal((await report(ctx, task, 0, F.successOutput(task))).code, 'TASK_NOT_EXECUTING');
    assert.deepEqual(snapshot(ctx), before);
    const failed = await report(ctx, task, 2, { protocolVersion: 1, outcome: 'invalid-input', mode: 'device',
      validityMode: 'fixed', siteVerification: 'PENDING', enrollment: null });
    assert.equal(failed.code, 0);
    assert.equal(failed.data.status, F.STATUS.FAILED_REVIEW);
  });
  await check('terminal-only-identical-complete-report-and-original-revision-replays', async () => {
    const ctx = await F.claimedFixture();
    const begun = await F.begin(ctx, ctx.task);
    assert.equal(begun.code, 0);
    const task = begun.data.task;
    const output = F.successOutput(task);
    assert.equal((await report(ctx, task, 0, output)).data.status, F.STATUS.PENDING_SITE_VERIFICATION);
    const before = snapshot(ctx);
    assert.equal((await report(ctx, task, 0, output)).data.idempotent, true);
    const differentSteps = structuredClone(output);
    differentSteps.steps[0].state = 'failed';
    differentSteps.enrollment.steps[0].state = 'failed';
    assert.equal((await report(ctx, task, 0, differentSteps)).code, 'REPORT_CONFLICT');
    assert.equal((await report(ctx, task, 0, output, task.revision + 1)).code, 'REPORT_CONFLICT');
    assert.deepEqual(snapshot(ctx), before);
  });
  await check('deadline-before-equal-after-and-no-extension', async () => {
    for (const delta of [-1, 0, 1]) {
      const ctx = await F.claimedFixture(), task = ctx.task;
      ctx.setNow(new Date(task.claimExpiresAt + delta));
      const begun = await F.begin(ctx, task);
      assert.equal(begun.code, delta < 0 ? 0 : 'CLAIM_EXPIRED');
      assert.equal(ctx.taskFor(ctx.applicationId).claimExpiresAt, task.claimExpiresAt);
    }
  });
  await check('claim-missing-worker-rejected-with-zero-write', async () => {
    const ctx = await F.queuedFixture(), before = snapshot(ctx);
    assert.equal((await ctx.main({ action: 'claimTask', workerToken: F.TOKEN })).code, 'INVALID_WORKER_ID');
    assert.deepEqual(snapshot(ctx), before);
  });
  await check('upload-eligibility-authoritative-regrant-and-terminal-history', async () => {
    const ctx = await F.approvedFixture();
    const poll = () => ctx.main({ action: 'getMyTask', applicationId: ctx.applicationId });
    assert.equal((await poll()).data.uploadEligible, true);
    await ctx.admin.setAllowlist([]);
    const before = snapshot(ctx);
    assert.equal((await poll()).code, 'ACCOUNT_NOT_ALLOWED');
    assert.deepEqual(snapshot(ctx), before);
    await ctx.admin.setAllowlist([F.OPENID]);
    assert.equal((await poll()).data.uploadEligible, true);
    const terminal = await F.claimedFixture();
    const begun = await F.begin(terminal, terminal.task);
    assert.equal((await report(terminal, begun.data.task, 0, F.successOutput(begun.data.task))).code, 0);
    await terminal.admin.setAllowlist([]);
    const terminalBefore = snapshot(terminal);
    const historical = await terminal.main({ action: 'getMyTask', applicationId: terminal.applicationId });
    assert.equal(historical.code, 0);
    assert.equal(historical.data.uploadEligible, false);
    assert.equal(historical.data.status, F.STATUS.PENDING_SITE_VERIFICATION);
    assert.deepEqual(snapshot(terminal), terminalBefore);
  });
  assert.deepEqual(codeHashes(), beforeCodeHashes, 'A reviewed implementation must remain unchanged');
  console.log(JSON.stringify({ scope: 'independent-cross-review-synthetic-only',
    registeredProjectTests: 0, codeHashes: beforeCodeHashes,
    fixturePrefixSha256: hash(source.slice(0, firstTest)), checks: results.length,
    interpretation: 'Public API control-flow and in-memory transaction simulation; not live SDK/cloud/device acceptance.',
    results }, null, 2));
})().catch((error) => { console.error('CROSS_REVIEW_ASSERTION_FAILED', error?.stack); process.exitCode = 1; });
