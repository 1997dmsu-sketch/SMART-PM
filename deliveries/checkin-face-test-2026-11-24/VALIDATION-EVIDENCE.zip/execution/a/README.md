# A 线修复实现与合成证据（2026-11-24）

固定实施基线 5398d1e。本目录是实施方自测证据，不构成独立验收。

- `focused-final.stdout.txt`：默认进程隔离，两个聚焦文件 63/63；stderr 空，exit0。
- `negative-controls/results.json`：五份明确命名的自有副本，分别禁用 namespace 事务重验、namespace setter 事务入口、report 执行态门、截止等号、worker 非空/严格绑定。
  对应断言失败数为 1/1/1/2/1，全部 exit1；无取消、skip、语法或导入失败。配置负控复现 true !== false，实际观察关停被陈旧写复活。
- 副本中负控完成后再次执行原候选，仍 63/63；没有把修改写回候选，也没有改旧取证日志。
- `focused-first.*` / `focused-second.*` 保留实现过程失败：初始内存 DB 对初始未读写 key 的冲突判定过严，以及旧报告测试缺少新增的 begin；这些不是最终结果。内存模型现在校验完整点读集，仍不冒充实际 CloudBase 隔离行为。
- `A-RESULTS.json` 记录最终实际 argv、cwd、Node 与本线源码字节哈希；辅助网络日志在 `network-events.jsonl`。

本次没有真实 SDK.init、真实云/设备请求、照片、凭据、worker CLI、HTTP/UI、部署或发布。没有执行旧库索引回填；旧非空名单无索引失败关闭。历史接口与原始日志未被重写。
