# C-01 独立复验

结论：**PASS**。**C-01 / P3：CLOSED**。原缺陷的触发序列已独立复验，旧登录回调不再取消有效新登录拥有的确认操作。没有发现本次 C 修法引入的可触发新问题。本结论只关闭固定修订的 C-01，不判定 B 四项、不扩大为部署或现场验收。

日期：2026-11-27，Asia/Shanghai。续原独立 C 会话；审查者未参与修复。原后台只读子审查仅交叉核对本次页面改动及用例覆盖，未执行测试或写文件。

## 固定对象与差异

- 工作区：`/workspace/SMART-PM-signed-remote-review-fix-20261127`。
- HEAD：`6fa36b5b60760d3d26fad2c95157954364e33e76`。
- 直接父：`66e0395c105cda21244d375ef6d01682bc6cfe1e`。
- 分支：`fix/signed-remote-independent-review-2026-11-27`。
- 初始及末尾源码状态均 clean；没有切换、替换、编辑或提交审查源码。
- 已检查祖先目录、仓库及 `.agents/.codex` 的适用 AGENTS.md，未发现文件。
- 原 C 报告仍为 10256 字节，SHA256 `5995974e915c46f88cb2a2b26028e4f1dcc8362b5fc42d64d7d6078af75190e9`；未改原报告、原源码基线或修复方工件。
- 相对直接父，C 行为改动仅 `miniprogram/pages/unlock/index.js`（20 行差异）；专属 `tests/signed-lease-frontend.test.cjs` 新增155行。配套 version.js/version.json、package version、来源 hash 清单和退修文档均已只读检查。提交另含 B 传输/worker 变更，交原 B 独立复验，本 C 不重复审。
- `miniprogram/services/api.js`、runtime、signedLeaseAccess 云函数、签约后台 facade/routes/页面相对直接父无差异；不重开已接受的 A 云/后台内容。
- 已读 `docs/tasks/SIGNED-LEASE-HIKVISION-REMOTE-OPEN-REMEDIATION-2026-11-27.md`，其 C-01 描述与源码一致。C 五项清单 entry（unlock page、frontend test、两个 version、package）的磁盘 SHA256 均与来源清单吻合；这是只读局部核对，没有运行冻结来源 gate。
- 小程序版本为 `0.1.0-beta.22-signed-lease-remote-source.2`，日期2026-11-27，仍标识“退修源码候选；未部署或设备验收”；runtime 两项实际功能开关仍 false。

## C-01 关闭依据

原触发：A request/query 未完成 → 换成 B → B 加载本人视图并打开确认或提交请求 → A 迟到回执进入旧 epoch 处理 → 通用清理释放 B 当前 operation、清空 B 门锁。

修订位置：

- `miniprogram/pages/unlock/index.js:74` 的 `clearPrivate` 在清私有数据时记录 `_privateViewEpoch`（`:78`）。
- `:94` 至 `:108` 的 `canUsePrivate/currentPrivateEpoch` 区分“当前无有效登录或视图尚属失效旧登录”与“有效 B 已接管视图”。`:100` 仅在前一情况清理，不因 A 旧 epoch 拒绝而释放 B 操作。
- `:125` 至 `:134` 的 `load` 在 loading 早退前先清旧 owner（`:127`），await 登录核对后再次检查捕获 epoch（`:133`），再接管视图（`:134`）。
- request 完成分支 `:228`、`:232` 与 query `:268`、`:274` 复用上述判断。旧 request finally 仍通过 `:120` 的 operation 对象所有权释放；旧 query finally `:281` 仍同时受 query 序号、有效 epoch 和页面可见性约束。

独立运行与静态核对覆盖：

| 场景 | 依据与观察 |
| --- | --- |
| A request/query 云返回成功或失败，B 已在 modal/request 内 | 定向用例 `tests/signed-lease-frontend.test.cjs:355` 至 `:387` 的8组合独立通过；B operation identity、viewVersion、私有数据和 pending/confirming 均保留；B 显式确认只提交一次。 |
| A 旧 query success/failure/finally，B 正在查询新任务 | `:412` 至 `:434` 独立通过；旧 finally 不释放 B 查询锁，不替换 B task。 |
| B 不经 onShow 直接 refresh，列表/记录挂起 | `:389` 至 `:410` 独立通过；立即清 A 数据且旧回执不改 B loading。另用独立 VM 在 **A 自己的旧 load 已挂起且 loading=true** 时换 B、直接 load，确认早退前接管有效。 |
| load await 身份核对期间换 epoch | 独立 VM 暂缓本地身份核对续体，换 B 后恢复；旧 load 不发列表调用，清旧私有数据；下一次 B load 正常。 |
| logout 或 B 尚未接管旧 A 视图 | `:436` 至 `:451` 独立通过；继续清 A 门锁/记录/signedOpen/operation，不为 B 提交。失败路径复用同一清理守卫，静态核对无分歧。 |
| 同 epoch hide/show、迟到 receipt、原 modal owner | 既有 `:202` 至 `:227`、`:260` 至 `:295` 在本次定向运行中通过，未发现保持回执或互斥行为退化。 |
| 原 C-01 序列 | 使用真实磁盘 api/gate/page 的独立 VM 重现；B modal 与视图保留，A 原请求1次、B 显式请求1次，B 结果归本人合同。 |
| 页面自身 fulfilled request/query 分支 | 真实 api 会把跨 epoch 的云成功转换为 AUTH_REQUIRED。为单独核对页面防线，独立 VM 仅把 API 边界替为内存 fulfilled promise；两个分支均保留 B modal，B 仍只显式提交1次。这是人工内存对照，不是实云可达性证明。 |

无新发现，因此本轮没有新增缺陷 ID、触发影响或修正要求；没有实施任何修正。

## 本次独立命令与工件

工作目录均为上述固定 worktree。两条实际业务检查命令如下（输出重定向仅写本 independent-C 目录）：

```sh
node --require ./tests/support/d-network-guard.cjs --test tests/signed-lease-frontend.test.cjs
node --require ./tests/support/d-network-guard.cjs /workspace/artifacts/signed-remote-remediation-2026-11-27/independent-C/vm-controls.cjs
```

第一条独立结果 **32/32，exit 0**，fail/cancelled/skipped均0。第二条独立结果 **五项离线 VM 对照通过，exit 0**，网络守卫无违规。VM 只读固定源码，用内存 WX 身份、列表、modal、云回执及本地延迟；没有网络、监听或真实发令。用例数不与继承结果相加。

下表路径相对 `/workspace/artifacts/signed-remote-remediation-2026-11-27/independent-C/`：

| 工件 | 字节数 | SHA256 |
| --- | ---: | --- |
| `frontend-tests.stdout.raw` | 3331 | `52f616d6bad0e3fc880d74e2bdc34339c8a9e4ec0b70d9b416c1adcfa450da84` |
| `frontend-tests.stderr.raw` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `frontend-tests.exit-code.txt`（0） | 2 | `9a271f2a916b0b6ee6cecb2426f0b3206ef074578be55d9bc94f6f3fe3ab86aa` |
| `vm-controls.cjs` | 9832 | `760acdbbc97fea9265c401a377b005a59c13fcfe1d8ddc563f18c76829d04310` |
| `vm-controls.stdout.raw` | 919 | `abdda5e80a2e90de1449042ba9cd91e0d5fbdf37b8bbc79e1b793b9568ad5634` |
| `vm-controls.stderr.raw` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `vm-controls.exit-code.txt`（0） | 2 | `9a271f2a916b0b6ee6cecb2426f0b3206ef074578be55d9bc94f6f3fe3ab86aa` |

继承证据单列：修复方 `C/final-green.log` 为3333字节、SHA256 `83571d9363cc01409e5305fd5149d23a57cb07d4782be21f630bf577ba11fbac`，记录32/32，只作继承；原 C 报告及旧610均未替代本次独立输出。

## 未验范围与停止边界

未运行610、全量npm、打包、CR2/EOF/WP06或其它冻结线；未安装、修改审查源码、启动真实UI/HTTP/worker、访问真实云/账号/设备/凭据/支付或上传小程序。B 四项由原 B 审查者另判；A 云/后台没有因本次局部修复重新验收。未验证真实微信生命周期、云事务/IAM/集合规则、设备协议或现场门锁释放，未裁定合同签署效力。

C-01 已关闭，本轮到此停手并交主 Codex。
