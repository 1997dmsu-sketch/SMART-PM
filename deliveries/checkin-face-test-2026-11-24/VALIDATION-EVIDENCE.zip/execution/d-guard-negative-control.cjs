'use strict';
const assert=require('node:assert/strict');
const guard=require('./d-network-guard-forward-mutant.cjs');
guard.assertLoadTimeClean();
const result=guard.selfTest();
assert.equal(result.ok,false);
assert.equal(result.attempts,guard.patchedCount);
assert.equal(result.caught,result.attempts);
assert.equal(result.forwarded,result.attempts);
assert.equal(guard.counters.forwarded,result.attempts);
assert.ok(result.entries.every(e=>e.canaryPositive&&e.forwarded===1&&e.restored));
process.stdout.write(JSON.stringify({negativeCaught:true,ok:result.ok,attempts:result.attempts,caught:result.caught,forwarded:result.forwarded})+'\n');
// This is the same assertion used by acceptance: mutation must exit 1 here.
assert.equal(result.ok,true,'D_NETWORK_GUARD_SELF_TEST_MUST_PASS');
